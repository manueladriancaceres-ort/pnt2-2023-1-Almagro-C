<script>
  import {IonPage} from '@ionic/vue'
  export default {
    components: { IonPage }
  }
</script>

<template>
  <ion-page>
    <h2>Home page</h2>
  </ion-page>
</template>
