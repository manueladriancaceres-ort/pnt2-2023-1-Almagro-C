<template>
  <ion-page>
    <h2>Error 404 Not found</h2>
  </ion-page>
</template>

<script>
  import {IonPage} from '@ionic/vue'
  export default {
    components: { IonPage }
  }
</script>

<style>

</style>