<template>
  <ion-page>
    <h2>This is an about page</h2>
  </ion-page>
</template>

<script>
  import {IonPage} from '@ionic/vue'
  export default {
    components: { IonPage }
  }
</script>


<style>
</style>
